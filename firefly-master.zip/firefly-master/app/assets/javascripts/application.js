//= require jquery
//= require local-time
//= require moment
//= require moment-timezone-with-data
//= require bootstrap-datetimepicker
//= require select2
//= require_tree .