class Intents::Stop
  include AlexaIntent

  def self.handle
    "This is the stop response"
  end

end
