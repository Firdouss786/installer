class Intents::Cancel
  include AlexaIntent

  def self.handle
    "This is the cancel response"
  end

end
