class Intents::Help
  include AlexaIntent

  def self.handle
    "This is the help response"
  end

end
