class InstallType
  def self.all
    "Linefit,Retrofit".split(',')
  end
end
