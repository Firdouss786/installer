class Aircraftprogram < ActiveRecord::Migration[5.1]
  def change
    drop_table :aircraftprogram
  end
end