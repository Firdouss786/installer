class Bomrestriction < ActiveRecord::Migration[5.1]
  def change
  	drop_table :bomrestriction
  end
end
