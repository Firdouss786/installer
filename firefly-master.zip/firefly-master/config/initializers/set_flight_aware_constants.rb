FIREFLY_NOTIFICATIONS_ENDPOINT = 'https://firefly.staging.topcareife.com/flight_notifications'
